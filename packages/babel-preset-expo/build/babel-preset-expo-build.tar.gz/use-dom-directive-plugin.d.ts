/**
 * Copyright © 2024 650 Industries.
 */
import { ConfigAPI } from '@babel/core';
export declare function expoUseDomDirectivePlugin(api: ConfigAPI): babel.PluginObj;
