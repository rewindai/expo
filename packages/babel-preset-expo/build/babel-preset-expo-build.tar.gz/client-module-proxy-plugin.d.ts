export declare function reactClientReferencesPlugin(): babel.PluginObj;
