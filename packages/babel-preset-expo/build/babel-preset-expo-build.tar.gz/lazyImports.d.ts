/** These Expo packages may have side-effects and should not be lazily initialized. */
export declare const lazyImports: Set<string>;
